using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MousePos : MonoBehaviour
{

    public float speed = 10f;
    public Vector3 targetPos;
    public Vector3 startPos;


    // Use this for initialization1
    void Start()
    {
        targetPos = new Vector3(0.25f, 1.5f, 0.5f);
        startPos = new Vector3(1, -1, -10);
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetKey("up"))
        {
            MoveObject(targetPos);

        } else if (Input.GetKey("down"))
        {
            MoveObject(startPos);
        }
        
    }

    void MoveObject(Vector3 newPos)
    {
       
        transform.LookAt(targetPos);
        transform.position = Vector3.MoveTowards(transform.position, newPos, speed * Time.deltaTime);    

    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sucessfulreach : MonoBehaviour
{
    // Start is called before the first frame update
    void OnTriggerEnter()
    {
        gameObject.GetComponent<Renderer>().material.color = Color.green;
    }
    void OnTriggerExit()
    {
        gameObject.GetComponent<Renderer>().material.color = Color.white;
    }
}
